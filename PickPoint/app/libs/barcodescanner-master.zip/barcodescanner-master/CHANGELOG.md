# Change Log

## [1.8.4] - Dec 30, 2015
* Improve performance by opening camera and handling preview frames in a separate HandlerThread (#1, #99)
* Do not automatically stopCamera after a result is found #115
* Update samples to use Material Theme and make sure all samples use the FullScreen theme
* Update gradle wrapper to v2.10, gradle plugin to v1.5.0, buildToolsVersion to v23.0.2 and targetSdkVersion 23

## [1.8.3] - October 3, 2015
* Rebuild ZBar libraries with position independent code (#123,#119,#94).
